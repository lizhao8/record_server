from .src.dynamic import TextDynamic, \
    DrawDynamic, UploadImages, InstantDynamic, \
    ScheduleDynamic, DynamicInfo, DynamicOperate